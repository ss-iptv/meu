<html lang="en"><head><style type="text/css">.swal-icon--error{border-color:#f27474;-webkit-animation:animateErrorIcon .5s;animation:animateErrorIcon .5s}.swal-icon--error__x-mark{position:relative;display:block;-webkit-animation:animateXMark .5s;animation:animateXMark .5s}.swal-icon--error__line{position:absolute;height:5px;width:47px;background-color:#f27474;display:block;top:37px;border-radius:2px}.swal-icon--error__line--left{-webkit-transform:rotate(45deg);transform:rotate(45deg);left:17px}.swal-icon--error__line--right{-webkit-transform:rotate(-45deg);transform:rotate(-45deg);right:16px}@-webkit-keyframes animateErrorIcon{0%{-webkit-transform:rotateX(100deg);transform:rotateX(100deg);opacity:0}to{-webkit-transform:rotateX(0deg);transform:rotateX(0deg);opacity:1}}@keyframes animateErrorIcon{0%{-webkit-transform:rotateX(100deg);transform:rotateX(100deg);opacity:0}to{-webkit-transform:rotateX(0deg);transform:rotateX(0deg);opacity:1}}@-webkit-keyframes animateXMark{0%{-webkit-transform:scale(.4);transform:scale(.4);margin-top:26px;opacity:0}50%{-webkit-transform:scale(.4);transform:scale(.4);margin-top:26px;opacity:0}80%{-webkit-transform:scale(1.15);transform:scale(1.15);margin-top:-6px}to{-webkit-transform:scale(1);transform:scale(1);margin-top:0;opacity:1}}@keyframes animateXMark{0%{-webkit-transform:scale(.4);transform:scale(.4);margin-top:26px;opacity:0}50%{-webkit-transform:scale(.4);transform:scale(.4);margin-top:26px;opacity:0}80%{-webkit-transform:scale(1.15);transform:scale(1.15);margin-top:-6px}to{-webkit-transform:scale(1);transform:scale(1);margin-top:0;opacity:1}}.swal-icon--warning{border-color:#f8bb86;-webkit-animation:pulseWarning .75s infinite alternate;animation:pulseWarning .75s infinite alternate}.swal-icon--warning__body{width:5px;height:47px;top:10px;border-radius:2px;margin-left:-2px}.swal-icon--warning__body,.swal-icon--warning__dot{position:absolute;left:50%;background-color:#f8bb86}.swal-icon--warning__dot{width:7px;height:7px;border-radius:50%;margin-left:-4px;bottom:-11px}@-webkit-keyframes pulseWarning{0%{border-color:#f8d486}to{border-color:#f8bb86}}@keyframes pulseWarning{0%{border-color:#f8d486}to{border-color:#f8bb86}}.swal-icon--success{border-color:#a5dc86}.swal-icon--success:after,.swal-icon--success:before{content:"";border-radius:50%;position:absolute;width:60px;height:120px;background:#fff;-webkit-transform:rotate(45deg);transform:rotate(45deg)}.swal-icon--success:before{border-radius:120px 0 0 120px;top:-7px;left:-33px;-webkit-transform:rotate(-45deg);transform:rotate(-45deg);-webkit-transform-origin:60px 60px;transform-origin:60px 60px}.swal-icon--success:after{border-radius:0 120px 120px 0;top:-11px;left:30px;-webkit-transform:rotate(-45deg);transform:rotate(-45deg);-webkit-transform-origin:0 60px;transform-origin:0 60px;-webkit-animation:rotatePlaceholder 4.25s ease-in;animation:rotatePlaceholder 4.25s ease-in}.swal-icon--success__ring{width:80px;height:80px;border:4px solid hsla(98,55%,69%,.2);border-radius:50%;box-sizing:content-box;position:absolute;left:-4px;top:-4px;z-index:2}.swal-icon--success__hide-corners{width:5px;height:90px;background-color:#fff;padding:1px;position:absolute;left:28px;top:8px;z-index:1;-webkit-transform:rotate(-45deg);transform:rotate(-45deg)}.swal-icon--success__line{height:5px;background-color:#a5dc86;display:block;border-radius:2px;position:absolute;z-index:2}.swal-icon--success__line--tip{width:25px;left:14px;top:46px;-webkit-transform:rotate(45deg);transform:rotate(45deg);-webkit-animation:animateSuccessTip .75s;animation:animateSuccessTip .75s}.swal-icon--success__line--long{width:47px;right:8px;top:38px;-webkit-transform:rotate(-45deg);transform:rotate(-45deg);-webkit-animation:animateSuccessLong .75s;animation:animateSuccessLong .75s}@-webkit-keyframes rotatePlaceholder{0%{-webkit-transform:rotate(-45deg);transform:rotate(-45deg)}5%{-webkit-transform:rotate(-45deg);transform:rotate(-45deg)}12%{-webkit-transform:rotate(-405deg);transform:rotate(-405deg)}to{-webkit-transform:rotate(-405deg);transform:rotate(-405deg)}}@keyframes rotatePlaceholder{0%{-webkit-transform:rotate(-45deg);transform:rotate(-45deg)}5%{-webkit-transform:rotate(-45deg);transform:rotate(-45deg)}12%{-webkit-transform:rotate(-405deg);transform:rotate(-405deg)}to{-webkit-transform:rotate(-405deg);transform:rotate(-405deg)}}@-webkit-keyframes animateSuccessTip{0%{width:0;left:1px;top:19px}54%{width:0;left:1px;top:19px}70%{width:50px;left:-8px;top:37px}84%{width:17px;left:21px;top:48px}to{width:25px;left:14px;top:45px}}@keyframes animateSuccessTip{0%{width:0;left:1px;top:19px}54%{width:0;left:1px;top:19px}70%{width:50px;left:-8px;top:37px}84%{width:17px;left:21px;top:48px}to{width:25px;left:14px;top:45px}}@-webkit-keyframes animateSuccessLong{0%{width:0;right:46px;top:54px}65%{width:0;right:46px;top:54px}84%{width:55px;right:0;top:35px}to{width:47px;right:8px;top:38px}}@keyframes animateSuccessLong{0%{width:0;right:46px;top:54px}65%{width:0;right:46px;top:54px}84%{width:55px;right:0;top:35px}to{width:47px;right:8px;top:38px}}.swal-icon--info{border-color:#c9dae1}.swal-icon--info:before{width:5px;height:29px;bottom:17px;border-radius:2px;margin-left:-2px}.swal-icon--info:after,.swal-icon--info:before{content:"";position:absolute;left:50%;background-color:#c9dae1}.swal-icon--info:after{width:7px;height:7px;border-radius:50%;margin-left:-3px;top:19px}.swal-icon{width:80px;height:80px;border-width:4px;border-style:solid;border-radius:50%;padding:0;position:relative;box-sizing:content-box;margin:20px auto}.swal-icon:first-child{margin-top:32px}.swal-icon--custom{width:auto;height:auto;max-width:100%;border:none;border-radius:0}.swal-icon img{max-width:100%;max-height:100%}.swal-title{color:rgba(0,0,0,.65);font-weight:600;text-transform:none;position:relative;display:block;padding:13px 16px;font-size:27px;line-height:normal;text-align:center;margin-bottom:0}.swal-title:first-child{margin-top:26px}.swal-title:not(:first-child){padding-bottom:0}.swal-title:not(:last-child){margin-bottom:13px}.swal-text{font-size:16px;position:relative;float:none;line-height:normal;vertical-align:top;text-align:left;display:inline-block;margin:0;padding:0 10px;font-weight:400;color:rgba(0,0,0,.64);max-width:calc(100% - 20px);overflow-wrap:break-word;box-sizing:border-box}.swal-text:first-child{margin-top:45px}.swal-text:last-child{margin-bottom:45px}.swal-footer{text-align:right;padding-top:13px;margin-top:13px;padding:13px 16px;border-radius:inherit;border-top-left-radius:0;border-top-right-radius:0}.swal-button-container{margin:5px;display:inline-block;position:relative}.swal-button{background-color:#7cd1f9;color:#fff;border:none;box-shadow:none;border-radius:5px;font-weight:600;font-size:14px;padding:10px 24px;margin:0;cursor:pointer}.swal-button:not([disabled]):hover{background-color:#78cbf2}.swal-button:active{background-color:#70bce0}.swal-button:focus{outline:none;box-shadow:0 0 0 1px #fff,0 0 0 3px rgba(43,114,165,.29)}.swal-button[disabled]{opacity:.5;cursor:default}.swal-button::-moz-focus-inner{border:0}.swal-button--cancel{color:#555;background-color:#efefef}.swal-button--cancel:not([disabled]):hover{background-color:#e8e8e8}.swal-button--cancel:active{background-color:#d7d7d7}.swal-button--cancel:focus{box-shadow:0 0 0 1px #fff,0 0 0 3px rgba(116,136,150,.29)}.swal-button--danger{background-color:#e64942}.swal-button--danger:not([disabled]):hover{background-color:#df4740}.swal-button--danger:active{background-color:#cf423b}.swal-button--danger:focus{box-shadow:0 0 0 1px #fff,0 0 0 3px rgba(165,43,43,.29)}.swal-content{padding:0 20px;margin-top:20px;font-size:medium}.swal-content:last-child{margin-bottom:20px}.swal-content__input,.swal-content__textarea{-webkit-appearance:none;background-color:#fff;border:none;font-size:14px;display:block;box-sizing:border-box;width:100%;border:1px solid rgba(0,0,0,.14);padding:10px 13px;border-radius:2px;transition:border-color .2s}.swal-content__input:focus,.swal-content__textarea:focus{outline:none;border-color:#6db8ff}.swal-content__textarea{resize:vertical}.swal-button--loading{color:transparent}.swal-button--loading~.swal-button__loader{opacity:1}.swal-button__loader{position:absolute;height:auto;width:43px;z-index:2;left:50%;top:50%;-webkit-transform:translateX(-50%) translateY(-50%);transform:translateX(-50%) translateY(-50%);text-align:center;pointer-events:none;opacity:0}.swal-button__loader div{display:inline-block;float:none;vertical-align:baseline;width:9px;height:9px;padding:0;border:none;margin:2px;opacity:.4;border-radius:7px;background-color:hsla(0,0%,100%,.9);transition:background .2s;-webkit-animation:swal-loading-anim 1s infinite;animation:swal-loading-anim 1s infinite}.swal-button__loader div:nth-child(3n+2){-webkit-animation-delay:.15s;animation-delay:.15s}.swal-button__loader div:nth-child(3n+3){-webkit-animation-delay:.3s;animation-delay:.3s}@-webkit-keyframes swal-loading-anim{0%{opacity:.4}20%{opacity:.4}50%{opacity:1}to{opacity:.4}}@keyframes swal-loading-anim{0%{opacity:.4}20%{opacity:.4}50%{opacity:1}to{opacity:.4}}.swal-overlay{position:fixed;top:0;bottom:0;left:0;right:0;text-align:center;font-size:0;overflow-y:auto;background-color:rgba(0,0,0,.4);z-index:10000;pointer-events:none;opacity:0;transition:opacity .3s}.swal-overlay:before{content:" ";display:inline-block;vertical-align:middle;height:100%}.swal-overlay--show-modal{opacity:1;pointer-events:auto}.swal-overlay--show-modal .swal-modal{opacity:1;pointer-events:auto;box-sizing:border-box;-webkit-animation:showSweetAlert .3s;animation:showSweetAlert .3s;will-change:transform}.swal-modal{width:478px;opacity:0;pointer-events:none;background-color:#fff;text-align:center;border-radius:5px;position:static;margin:20px auto;display:inline-block;vertical-align:middle;-webkit-transform:scale(1);transform:scale(1);-webkit-transform-origin:50% 50%;transform-origin:50% 50%;z-index:10001;transition:opacity .2s,-webkit-transform .3s;transition:transform .3s,opacity .2s;transition:transform .3s,opacity .2s,-webkit-transform .3s}@media (max-width:500px){.swal-modal{width:calc(100% - 20px)}}@-webkit-keyframes showSweetAlert{0%{-webkit-transform:scale(1);transform:scale(1)}1%{-webkit-transform:scale(.5);transform:scale(.5)}45%{-webkit-transform:scale(1.05);transform:scale(1.05)}80%{-webkit-transform:scale(.95);transform:scale(.95)}to{-webkit-transform:scale(1);transform:scale(1)}}@keyframes showSweetAlert{0%{-webkit-transform:scale(1);transform:scale(1)}1%{-webkit-transform:scale(.5);transform:scale(.5)}45%{-webkit-transform:scale(1.05);transform:scale(1.05)}80%{-webkit-transform:scale(.95);transform:scale(.95)}to{-webkit-transform:scale(1);transform:scale(1)}}</style>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title></title>

<!-- Bootstrap -->
<style>
:root {
  --primary-color: #fff;
  --dark-gray: #222;
  --almost-black: #111;
  --semi-white: #ccc;
  --blue: #3498db;
  --red: #e74c3c;
  
  --standard: 1.25rem;
  --big: 2rem;
  --small: 0.7rem;
  
  --serif: Georgia, serif;
}
</style>
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/owl.carousel.css" rel="stylesheet">
<link href="css/font-awesome.min.css" rel="stylesheet">
<link href="css/scrollbar.css" rel="stylesheet">

<script src="js/jquery-1.11.3.min.js"></script> 
<link rel="stylesheet" type="text/css" href="css/rippler.css">


<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
    #cbp-spmenu-s1
    {
      padding-bottom: 80px;
    }
  </style>
<style type="text/css">@-webkit-keyframes bounce{0%,20%,50%,80%,to{-webkit-transform:translateY(0);transform:translateY(0)}40%{-webkit-transform:translateY(-30px);transform:translateY(-30px)}60%{-webkit-transform:translateY(-15px);transform:translateY(-15px)}}@keyframes bounce{0%,20%,50%,80%,to{-webkit-transform:translateY(0);transform:translateY(0)}40%{-webkit-transform:translateY(-30px);transform:translateY(-30px)}60%{-webkit-transform:translateY(-15px);transform:translateY(-15px)}}.om-animation-bounce{-webkit-animation-duration:1s;animation-duration:1s;-webkit-animation-fill-mode:both;animation-fill-mode:both;-webkit-animation-name:bounce;animation-name:bounce}@-webkit-keyframes bounceIn{0%{opacity:0;-webkit-transform:scale(.3);transform:scale(.3)}50%{opacity:1;-webkit-transform:scale(1.05);transform:scale(1.05)}70%{-webkit-transform:scale(.9);transform:scale(.9)}to{opacity:1;-webkit-transform:scale(1);transform:scale(1)}}@keyframes bounceIn{0%{opacity:0;-webkit-transform:scale(.3);transform:scale(.3)}50%{opacity:1;-webkit-transform:scale(1.05);transform:scale(1.05)}70%{-webkit-transform:scale(.9);transform:scale(.9)}to{opacity:1;-webkit-transform:scale(1);transform:scale(1)}}.om-animation-bounce-in{-webkit-animation-duration:1s;animation-duration:1s;-webkit-animation-name:bounceIn;animation-name:bounceIn}@-webkit-keyframes bounceInDown{0%{opacity:0;-webkit-transform:translateY(-2000px);transform:translateY(-2000px)}60%{opacity:1;-webkit-transform:translateY(30px);transform:translateY(30px)}80%{-webkit-transform:translateY(-10px);transform:translateY(-10px)}to{-webkit-transform:translateY(0);transform:translateY(0)}}@keyframes bounceInDown{0%{opacity:0;-webkit-transform:translateY(-2000px);transform:translateY(-2000px)}60%{opacity:1;-webkit-transform:translateY(30px);transform:translateY(30px)}80%{-webkit-transform:translateY(-10px);transform:translateY(-10px)}to{-webkit-transform:translateY(0);transform:translateY(0)}}.om-animation-bounce-in-down{-webkit-animation-duration:1s;animation-duration:1s;-webkit-animation-name:bounceInDown;animation-name:bounceInDown}@-webkit-keyframes bounceInLeft{0%{opacity:0;-webkit-transform:translateX(-2000px);transform:translateX(-2000px)}60%{opacity:1;-webkit-transform:translateX(30px);transform:translateX(30px)}80%{-webkit-transform:translateX(-10px);transform:translateX(-10px)}to{-webkit-transform:translateX(0);transform:translateX(0)}}@keyframes bounceInLeft{0%{opacity:0;-webkit-transform:translateX(-2000px);transform:translateX(-2000px)}60%{opacity:1;-webkit-transform:translateX(30px);transform:translateX(30px)}80%{-webkit-transform:translateX(-10px);transform:translateX(-10px)}to{-webkit-transform:translateX(0);transform:translateX(0)}}.om-animation-bounce-in-left{-webkit-animation-duration:1s;animation-duration:1s;-webkit-animation-name:bounceInLeft;animation-name:bounceInLeft}@-webkit-keyframes bounceInRight{0%{opacity:0;-webkit-transform:translateX(2000px);transform:translateX(2000px)}60%{opacity:1;-webkit-transform:translateX(-30px);transform:translateX(-30px)}80%{-webkit-transform:translateX(10px);transform:translateX(10px)}to{-webkit-transform:translateX(0);transform:translateX(0)}}@keyframes bounceInRight{0%{opacity:0;-webkit-transform:translateX(2000px);transform:translateX(2000px)}60%{opacity:1;-webkit-transform:translateX(-30px);transform:translateX(-30px)}80%{-webkit-transform:translateX(10px);transform:translateX(10px)}to{-webkit-transform:translateX(0);transform:translateX(0)}}.om-animation-bounce-in-right{-webkit-animation-duration:1s;animation-duration:1s;-webkit-animation-name:bounceInRight;animation-name:bounceInRight}@-webkit-keyframes bounceInUp{0%{opacity:0;-webkit-transform:translateY(2000px);transform:translateY(2000px)}60%{opacity:1;-webkit-transform:translateY(-30px);transform:translateY(-30px)}80%{-webkit-transform:translateY(10px);transform:translateY(10px)}to{-webkit-transform:translateY(0);transform:translateY(0)}}@keyframes bounceInUp{0%{opacity:0;-webkit-transform:translateY(2000px);transform:translateY(2000px)}60%{opacity:1;-webkit-transform:translateY(-30px);transform:translateY(-30px)}80%{-webkit-transform:translateY(10px);transform:translateY(10px)}to{-webkit-transform:translateY(0);transform:translateY(0)}}.om-animation-bounce-in-up{-webkit-animation-duration:1s;animation-duration:1s;-webkit-animation-name:bounceInUp;animation-name:bounceInUp}@-webkit-keyframes flash{0%,50%,to{opacity:1}25%,75%{opacity:0}}@keyframes flash{0%,50%,to{opacity:1}25%,75%{opacity:0}}.om-animation-flash{-webkit-animation-duration:1s;animation-duration:1s;-webkit-animation-fill-mode:both;animation-fill-mode:both;-webkit-animation-name:flash;animation-name:flash}@-webkit-keyframes flip{0%{-webkit-transform:perspective(800px) translateZ(0) rotateY(0) scale(1);transform:perspective(800px) translateZ(0) rotateY(0) scale(1);-webkit-animation-timing-function:ease-out;animation-timing-function:ease-out}40%{-webkit-transform:perspective(800px) translateZ(150px) rotateY(170deg) scale(1);transform:perspective(800px) translateZ(150px) rotateY(170deg) scale(1);-webkit-animation-timing-function:ease-out;animation-timing-function:ease-out}50%{-webkit-transform:perspective(800px) translateZ(150px) rotateY(190deg) scale(1);transform:perspective(800px) translateZ(150px) rotateY(190deg) scale(1);-webkit-animation-timing-function:ease-in;animation-timing-function:ease-in}80%{-webkit-transform:perspective(800px) translateZ(0) rotateY(1turn) scale(.95);transform:perspective(800px) translateZ(0) rotateY(1turn) scale(.95);-webkit-animation-timing-function:ease-in;animation-timing-function:ease-in}to{-webkit-transform:perspective(800px) translateZ(0) rotateY(1turn) scale(1);transform:perspective(800px) translateZ(0) rotateY(1turn) scale(1);-webkit-animation-timing-function:ease-in;animation-timing-function:ease-in}}@keyframes flip{0%{-webkit-transform:perspective(800px) translateZ(0) rotateY(0) scale(1);transform:perspective(800px) translateZ(0) rotateY(0) scale(1);-webkit-animation-timing-function:ease-out;animation-timing-function:ease-out}40%{-webkit-transform:perspective(800px) translateZ(150px) rotateY(170deg) scale(1);transform:perspective(800px) translateZ(150px) rotateY(170deg) scale(1);-webkit-animation-timing-function:ease-out;animation-timing-function:ease-out}50%{-webkit-transform:perspective(800px) translateZ(150px) rotateY(190deg) scale(1);transform:perspective(800px) translateZ(150px) rotateY(190deg) scale(1);-webkit-animation-timing-function:ease-in;animation-timing-function:ease-in}80%{-webkit-transform:perspective(800px) translateZ(0) rotateY(1turn) scale(.95);transform:perspective(800px) translateZ(0) rotateY(1turn) scale(.95);-webkit-animation-timing-function:ease-in;animation-timing-function:ease-in}to{-webkit-transform:perspective(800px) translateZ(0) rotateY(1turn) scale(1);transform:perspective(800px) translateZ(0) rotateY(1turn) scale(1);-webkit-animation-timing-function:ease-in;animation-timing-function:ease-in}}.om-animation-flip{-webkit-animation-duration:1s;animation-duration:1s;-webkit-backface-visibility:visible;backface-visibility:visible;-webkit-animation-name:flip;animation-name:flip}@-webkit-keyframes flipInX{0%{-webkit-transform:perspective(800px) rotateX(90deg);transform:perspective(800px) rotateX(90deg);opacity:0}40%{-webkit-transform:perspective(800px) rotateX(-10deg);transform:perspective(800px) rotateX(-10deg)}70%{-webkit-transform:perspective(800px) rotateX(10deg);transform:perspective(800px) rotateX(10deg)}to{-webkit-transform:perspective(800px) rotateX(0deg);transform:perspective(800px) rotateX(0deg);opacity:1}}@keyframes flipInX{0%{-webkit-transform:perspective(800px) rotateX(90deg);transform:perspective(800px) rotateX(90deg);opacity:0}40%{-webkit-transform:perspective(800px) rotateX(-10deg);transform:perspective(800px) rotateX(-10deg)}70%{-webkit-transform:perspective(800px) rotateX(10deg);transform:perspective(800px) rotateX(10deg)}to{-webkit-transform:perspective(800px) rotateX(0deg);transform:perspective(800px) rotateX(0deg);opacity:1}}.om-animation-flip-down{-webkit-animation-duration:1s;animation-duration:1s;-webkit-backface-visibility:visible;backface-visibility:visible;-webkit-animation-name:flipInX;animation-name:flipInX}@-webkit-keyframes flipInY{0%{-webkit-transform:perspective(800px) rotateY(90deg);transform:perspective(800px) rotateY(90deg);opacity:0}40%{-webkit-transform:perspective(800px) rotateY(-10deg);transform:perspective(800px) rotateY(-10deg)}70%{-webkit-transform:perspective(800px) rotateY(10deg);transform:perspective(800px) rotateY(10deg)}to{-webkit-transform:perspective(800px) rotateY(0deg);transform:perspective(800px) rotateY(0deg);opacity:1}}@keyframes flipInY{0%{-webkit-transform:perspective(800px) rotateY(90deg);transform:perspective(800px) rotateY(90deg);opacity:0}40%{-webkit-transform:perspective(800px) rotateY(-10deg);transform:perspective(800px) rotateY(-10deg)}70%{-webkit-transform:perspective(800px) rotateY(10deg);transform:perspective(800px) rotateY(10deg)}to{-webkit-transform:perspective(800px) rotateY(0deg);transform:perspective(800px) rotateY(0deg);opacity:1}}.om-animation-flip-side{-webkit-animation-duration:1s;animation-duration:1s;-webkit-backface-visibility:visible;backface-visibility:visible;-webkit-animation-name:flipInY;animation-name:flipInY}@-webkit-keyframes lightSpeedIn{0%{-webkit-transform:translateX(100%) skewX(-30deg);transform:translateX(100%) skewX(-30deg);opacity:0}60%{-webkit-transform:translateX(-20%) skewX(30deg);transform:translateX(-20%) skewX(30deg);opacity:1}80%{-webkit-transform:translateX(0) skewX(-15deg);transform:translateX(0) skewX(-15deg);opacity:1}to{-webkit-transform:translateX(0) skewX(0deg);transform:translateX(0) skewX(0deg);opacity:1}}@keyframes lightSpeedIn{0%{-webkit-transform:translateX(100%) skewX(-30deg);transform:translateX(100%) skewX(-30deg);opacity:0}60%{-webkit-transform:translateX(-20%) skewX(30deg);transform:translateX(-20%) skewX(30deg);opacity:1}80%{-webkit-transform:translateX(0) skewX(-15deg);transform:translateX(0) skewX(-15deg);opacity:1}to{-webkit-transform:translateX(0) skewX(0deg);transform:translateX(0) skewX(0deg);opacity:1}}.om-animation-light-speed{-webkit-animation-duration:1s;animation-duration:1s;-webkit-animation-name:lightSpeedIn;animation-name:lightSpeedIn;-webkit-animation-timing-function:ease-out;animation-timing-function:ease-out}@-webkit-keyframes pulse{0%{-webkit-transform:scale(1);transform:scale(1)}50%{-webkit-transform:scale(1.1);transform:scale(1.1)}to{-webkit-transform:scale(1);transform:scale(1)}}@keyframes pulse{0%{-webkit-transform:scale(1);transform:scale(1)}50%{-webkit-transform:scale(1.1);transform:scale(1.1)}to{-webkit-transform:scale(1);transform:scale(1)}}.om-animation-pulse{-webkit-animation-duration:1s;animation-duration:1s;-webkit-animation-fill-mode:both;animation-fill-mode:both;-webkit-animation-name:pulse;animation-name:pulse}@-webkit-keyframes rollIn{0%{opacity:0;-webkit-transform:translateX(-100%) rotate(-120deg);transform:translateX(-100%) rotate(-120deg)}to{opacity:1;-webkit-transform:translateX(0) rotate(0deg);transform:translateX(0) rotate(0deg)}}@keyframes rollIn{0%{opacity:0;-webkit-transform:translateX(-100%) rotate(-120deg);transform:translateX(-100%) rotate(-120deg)}to{opacity:1;-webkit-transform:translateX(0) rotate(0deg);transform:translateX(0) rotate(0deg)}}.om-animation-roll-in{-webkit-animation-duration:1s;animation-duration:1s;-webkit-animation-name:rollIn;animation-name:rollIn}@-webkit-keyframes rotateIn{0%{-webkit-transform-origin:center center;transform-origin:center center;-webkit-transform:rotate(-200deg);transform:rotate(-200deg);opacity:0}to{-webkit-transform-origin:center center;transform-origin:center center;-webkit-transform:rotate(0);transform:rotate(0);opacity:1}}@keyframes rotateIn{0%{-webkit-transform-origin:center center;transform-origin:center center;-webkit-transform:rotate(-200deg);transform:rotate(-200deg);opacity:0}to{-webkit-transform-origin:center center;transform-origin:center center;-webkit-transform:rotate(0);transform:rotate(0);opacity:1}}.om-animation-rotate{-webkit-animation-duration:1s;animation-duration:1s;-webkit-animation-name:rotateIn;animation-name:rotateIn}@-webkit-keyframes rotateInDownLeft{0%{-webkit-transform-origin:left bottom;transform-origin:left bottom;-webkit-transform:rotate(-90deg);transform:rotate(-90deg);opacity:0}to{-webkit-transform-origin:left bottom;transform-origin:left bottom;-webkit-transform:rotate(0);transform:rotate(0);opacity:1}}@keyframes rotateInDownLeft{0%{-webkit-transform-origin:left bottom;transform-origin:left bottom;-webkit-transform:rotate(-90deg);transform:rotate(-90deg);opacity:0}to{-webkit-transform-origin:left bottom;transform-origin:left bottom;-webkit-transform:rotate(0);transform:rotate(0);opacity:1}}.om-animation-rotate-down-left{-webkit-animation-duration:1s;animation-duration:1s;-webkit-animation-name:rotateInDownLeft;animation-name:rotateInDownLeft}@-webkit-keyframes rotateInDownRight{0%{-webkit-transform-origin:right bottom;transform-origin:right bottom;-webkit-transform:rotate(90deg);transform:rotate(90deg);opacity:0}to{-webkit-transform-origin:right bottom;transform-origin:right bottom;-webkit-transform:rotate(0);transform:rotate(0);opacity:1}}@keyframes rotateInDownRight{0%{-webkit-transform-origin:right bottom;transform-origin:right bottom;-webkit-transform:rotate(90deg);transform:rotate(90deg);opacity:0}to{-webkit-transform-origin:right bottom;transform-origin:right bottom;-webkit-transform:rotate(0);transform:rotate(0);opacity:1}}.om-animation-rotate-down-right{-webkit-animation-duration:1s;animation-duration:1s;-webkit-animation-name:rotateInDownRight;animation-name:rotateInDownRight}@-webkit-keyframes rotateInUpLeft{0%{-webkit-transform-origin:left bottom;transform-origin:left bottom;-webkit-transform:rotate(90deg);transform:rotate(90deg);opacity:0}to{-webkit-transform-origin:left bottom;transform-origin:left bottom;-webkit-transform:rotate(0);transform:rotate(0);opacity:1}}@keyframes rotateInUpLeft{0%{-webkit-transform-origin:left bottom;transform-origin:left bottom;-webkit-transform:rotate(90deg);transform:rotate(90deg);opacity:0}to{-webkit-transform-origin:left bottom;transform-origin:left bottom;-webkit-transform:rotate(0);transform:rotate(0);opacity:1}}.om-animation-rotate-up-left{-webkit-animation-duration:1s;animation-duration:1s;-webkit-animation-name:rotateInUpLeft;animation-name:rotateInUpLeft}@-webkit-keyframes rotateInUpRight{0%{-webkit-transform-origin:right bottom;transform-origin:right bottom;-webkit-transform:rotate(-90deg);transform:rotate(-90deg);opacity:0}to{-webkit-transform-origin:right bottom;transform-origin:right bottom;-webkit-transform:rotate(0);transform:rotate(0);opacity:1}}@keyframes rotateInUpRight{0%{-webkit-transform-origin:right bottom;transform-origin:right bottom;-webkit-transform:rotate(-90deg);transform:rotate(-90deg);opacity:0}to{-webkit-transform-origin:right bottom;transform-origin:right bottom;-webkit-transform:rotate(0);transform:rotate(0);opacity:1}}.om-animation-rotate-up-right{-webkit-animation-duration:1s;animation-duration:1s;-webkit-animation-name:rotateInUpRight;animation-name:rotateInUpRight}@-webkit-keyframes rubberBand{0%{-webkit-transform:scale(1);transform:scale(1)}30%{-webkit-transform:scaleX(1.25) scaleY(.75);transform:scaleX(1.25) scaleY(.75)}40%{-webkit-transform:scaleX(.75) scaleY(1.25);transform:scaleX(.75) scaleY(1.25)}60%{-webkit-transform:scaleX(1.15) scaleY(.85);transform:scaleX(1.15) scaleY(.85)}to{-webkit-transform:scale(1);transform:scale(1)}}@keyframes rubberBand{0%{-webkit-transform:scale(1);transform:scale(1)}30%{-webkit-transform:scaleX(1.25) scaleY(.75);transform:scaleX(1.25) scaleY(.75)}40%{-webkit-transform:scaleX(.75) scaleY(1.25);transform:scaleX(.75) scaleY(1.25)}60%{-webkit-transform:scaleX(1.15) scaleY(.85);transform:scaleX(1.15) scaleY(.85)}to{-webkit-transform:scale(1);transform:scale(1)}}.om-animation-rubber-band{-webkit-animation-duration:1s;animation-duration:1s;-webkit-animation-fill-mode:both;animation-fill-mode:both;-webkit-animation-name:rubberBand;animation-name:rubberBand}@-webkit-keyframes shake{0%,to{-webkit-transform:translateX(0);transform:translateX(0)}10%,30%,50%,70%,90%{-webkit-transform:translateX(-10px);transform:translateX(-10px)}20%,40%,60%,80%{-webkit-transform:translateX(10px);transform:translateX(10px)}}@keyframes shake{0%,to{-webkit-transform:translateX(0);transform:translateX(0)}10%,30%,50%,70%,90%{-webkit-transform:translateX(-10px);transform:translateX(-10px)}20%,40%,60%,80%{-webkit-transform:translateX(10px);transform:translateX(10px)}}.om-animation-shake{-webkit-animation-duration:1s;animation-duration:1s;-webkit-animation-fill-mode:both;animation-fill-mode:both;-webkit-animation-name:shake;animation-name:shake}@-webkit-keyframes slideInDown{0%{opacity:0;-webkit-transform:translateY(-2000px);transform:translateY(-2000px)}to{-webkit-transform:translateY(0);transform:translateY(0)}}@keyframes slideInDown{0%{opacity:0;-webkit-transform:translateY(-2000px);transform:translateY(-2000px)}to{-webkit-transform:translateY(0);transform:translateY(0)}}.om-animation-slide-in-down{-webkit-animation-duration:1s;animation-duration:1s;-webkit-animation-name:slideInDown;animation-name:slideInDown}@-webkit-keyframes slideInLeft{0%{opacity:0;-webkit-transform:translateX(-2000px);transform:translateX(-2000px)}to{-webkit-transform:translateX(0);transform:translateX(0)}}@keyframes slideInLeft{0%{opacity:0;-webkit-transform:translateX(-2000px);transform:translateX(-2000px)}to{-webkit-transform:translateX(0);transform:translateX(0)}}.om-animation-slide-in-left{-webkit-animation-duration:1s;animation-duration:1s;-webkit-animation-name:slideInLeft;animation-name:slideInLeft}@-webkit-keyframes slideInRight{0%{opacity:0;-webkit-transform:translateX(2000px);transform:translateX(2000px)}to{-webkit-transform:translateX(0);transform:translateX(0)}}@keyframes slideInRight{0%{opacity:0;-webkit-transform:translateX(2000px);transform:translateX(2000px)}to{-webkit-transform:translateX(0);transform:translateX(0)}}.om-animation-slide-in-right{-webkit-animation-duration:1s;animation-duration:1s;-webkit-animation-name:slideInRight;animation-name:slideInRight}@-webkit-keyframes swing{20%{-webkit-transform:rotate(15deg);transform:rotate(15deg)}40%{-webkit-transform:rotate(-10deg);transform:rotate(-10deg)}60%{-webkit-transform:rotate(5deg);transform:rotate(5deg)}80%{-webkit-transform:rotate(-5deg);transform:rotate(-5deg)}to{-webkit-transform:rotate(0deg);transform:rotate(0deg)}}@keyframes swing{20%{-webkit-transform:rotate(15deg);transform:rotate(15deg)}40%{-webkit-transform:rotate(-10deg);transform:rotate(-10deg)}60%{-webkit-transform:rotate(5deg);transform:rotate(5deg)}80%{-webkit-transform:rotate(-5deg);transform:rotate(-5deg)}to{-webkit-transform:rotate(0deg);transform:rotate(0deg)}}.om-animation-swing{-webkit-animation-duration:1s;animation-duration:1s;-webkit-transform-origin:top center;transform-origin:top center;-webkit-animation-name:swing;animation-name:swing}@-webkit-keyframes tada{0%{-webkit-transform:scale(1);transform:scale(1)}10%,20%{-webkit-transform:scale(.9) rotate(-3deg);transform:scale(.9) rotate(-3deg)}30%,50%,70%,90%{-webkit-transform:scale(1.1) rotate(3deg);transform:scale(1.1) rotate(3deg)}40%,60%,80%{-webkit-transform:scale(1.1) rotate(-3deg);transform:scale(1.1) rotate(-3deg)}to{-webkit-transform:scale(1) rotate(0);transform:scale(1) rotate(0)}}@keyframes tada{0%{-webkit-transform:scale(1);transform:scale(1)}10%,20%{-webkit-transform:scale(.9) rotate(-3deg);transform:scale(.9) rotate(-3deg)}30%,50%,70%,90%{-webkit-transform:scale(1.1) rotate(3deg);transform:scale(1.1) rotate(3deg)}40%,60%,80%{-webkit-transform:scale(1.1) rotate(-3deg);transform:scale(1.1) rotate(-3deg)}to{-webkit-transform:scale(1) rotate(0);transform:scale(1) rotate(0)}}.om-animation-tada{-webkit-animation-duration:1s;animation-duration:1s;-webkit-animation-name:tada;animation-name:tada}@-webkit-keyframes wobble{0%{-webkit-transform:translateX(0);transform:translateX(0)}15%{-webkit-transform:translateX(-25%) rotate(-5deg);transform:translateX(-25%) rotate(-5deg)}30%{-webkit-transform:translateX(20%) rotate(3deg);transform:translateX(20%) rotate(3deg)}45%{-webkit-transform:translateX(-15%) rotate(-3deg);transform:translateX(-15%) rotate(-3deg)}60%{-webkit-transform:translateX(10%) rotate(2deg);transform:translateX(10%) rotate(2deg)}75%{-webkit-transform:translateX(-5%) rotate(-1deg);transform:translateX(-5%) rotate(-1deg)}to{-webkit-transform:translateX(0);transform:translateX(0)}}@keyframes wobble{0%{-webkit-transform:translateX(0);transform:translateX(0)}15%{-webkit-transform:translateX(-25%) rotate(-5deg);transform:translateX(-25%) rotate(-5deg)}30%{-webkit-transform:translateX(20%) rotate(3deg);transform:translateX(20%) rotate(3deg)}45%{-webkit-transform:translateX(-15%) rotate(-3deg);transform:translateX(-15%) rotate(-3deg)}60%{-webkit-transform:translateX(10%) rotate(2deg);transform:translateX(10%) rotate(2deg)}75%{-webkit-transform:translateX(-5%) rotate(-1deg);transform:translateX(-5%) rotate(-1deg)}to{-webkit-transform:translateX(0);transform:translateX(0)}}.om-animation-wobble{-webkit-animation-duration:1s;animation-duration:1s;-webkit-animation-name:wobble;animation-name:wobble}.om-content-lock{color:transparent!important;text-shadow:rgba(0,0,0,.5) 0 0 10px;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;pointer-events:none;filter:url("data:image/svg+xml;utf9,<svg%20version='1.1'%20xmlns='http://www.w3.org/2000/svg'><filter%20id='blur'><feGaussianBlur%20stdDeviation='10'%20/></filter></svg>#blur");-webkit-filter:blur(10px);-ms-filter:blur(10px);-o-filter:blur(10px);filter:blur(10px)}html.om-mobile-position,html.om-mobile-position body{position:fixed!important}html.om-ios-form,html.om-ios-form body{-webkit-transform:translateZ(0)!important;transform:translateZ(0)!important;-webkit-overflow-scrolling:touch!important;height:100%!important;overflow:auto!important}html.om-position-popup body{overflow:hidden!important}html.om-position-floating-top{transition:padding-top .5s ease!important}html.om-position-floating-bottom{transition:padding-bottom .5s ease!important}html.om-reset-dimensions{height:100%!important;width:100%!important}.om-verification-confirmation{font-family:Lato,Arial,Helvetica,sans-serif;position:fixed;border-radius:10px;bottom:20px;left:20px;padding:10px 20px;opacity:0;transition:opacity .3s ease-in;background:#85bf31;color:#fff;font-size:18px;font-weight:700;z-index:9999}</style></head>
<body>

	<div class="body-content">
  	<div class="overlay"></div>
    
  	
<style type="text/css">
  div#SuccessMessage {
      position: fixed;
      top: -100%;
      left: 35%;
      width: 30%;
  }
  h3.SettingsHeadings {
        color: #fff;
      text-align: left;
  }

  .switch {
      position: relative;
      display: inline-block;
      width: 60px;
      height: 34px;
    }

    .switch input {display:none;}

    .slider {
      position: absolute;
      cursor: pointer;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: #ccc;
      -webkit-transition: .4s;
      transition: .4s;
    }

    .slider:before {
      position: absolute;
      content: "";
      height: 26px;
      width: 26px;
      left: 4px;
      bottom: 4px;
      background-color: white;
      -webkit-transition: .4s;
      transition: .4s;
    }

    input:checked + .slider {
      background-color: #2196F3;
    }

    input:focus + .slider {
      box-shadow: 0 0 1px #2196F3;
    }

    input:checked + .slider:before {
      -webkit-transform: translateX(26px);
      -ms-transform: translateX(26px);
      transform: translateX(26px);
    }

    /* Rounded sliders */
    .slider.round {
      border-radius: 34px;
    }

    .slider.round:before {
      border-radius: 50%;
    }

    .addredborder
    {
      border:1px solid red !important;
    }

    .modal-backdrop {
        z-index: 1040 !important;
    }
    .modal-dialog {
        z-index: 1100 !important;
    }

    .in {
      background: rgba(0, 0, 0, 0.95);
      }

      button#UpdateParentPassword {
          position: relative;
          top: 18px;
      }
      .commoncs2, .commoncs2:focus, .commoncs2:active
      {
          background: transparent;
          color: #000 !important;
          padding: 0;
          box-shadow: none;
          outline: none;
          border: 0;
          border-bottom: 1px solid #000;
          border-radius: 0;
      }
      .commoncs2::-webkit-input-placeholder {
          color: #000 !important;
        }
        
      .commoncs2::-moz-placeholder {
         color: #000 !important;
      }
      .commoncs2::-webkit-input-placeholder {
         color: #000 !important;
      }
      .commoncs2::-ms-input-placeholder{
         color: #000 !important;
      }

    td.common-td {
         width: 40%;
    }

   .disableInputs
   {
      cursor: not-allowed;
   }

   a.showbtn {
      top: -22px;
      position: relative;
      left: 94%;
  } 

  .commoncs {
    position: relative;
    top: 10px;
}


.form-control, .form-control:focus, .form-control:active {
     border-bottom: none !important; 
  }

  .table-bordered > thead > tr > th, .table-bordered > tbody > tr > th, .table-bordered > tfoot > tr > th, .table-bordered > thead > tr > td, .table-bordered > tbody > tr > td, .table-bordered > tfoot > tr > td {
      border: 1px solid #dadada52 !important;
      padding: 5px 10px !important;
      line-height: 30px !important;
  }

  .commoncs, .commoncs:focus, .commoncs:active 
  { 
      border-bottom: 1px solid #dadada52 !important;
  }
  .commoncs2, .commoncs2:focus, .commoncs2:active 
  { 
      border-bottom: 1px solid #000 !important;
  }


a.popsbtn {
    top: -32px;
}

.commonsectionclass table {
    border: none !important;
}

.commonsectionclass tr {
    border: none !important;
}


.commonsectionclass td {
    border: none !important;
}
.table-bordered > thead > tr > th, .table-bordered > tbody > tr > th, .table-bordered > tfoot > tr > th, .table-bordered > thead > tr > td, .table-bordered > tbody > tr > td, .table-bordered > tfoot > tr > td
{
  border: none !important;
  padding:10px 10px !important
}

.main-sheading
{
      border-bottom: 1px solid #aaa;
    padding-bottom: 10px;
}

.commonsectionclass {
    border-bottom: 1px groove #aaa;
}

.commonsectionclass .form-control {
    border-bottom: 1px groove #aaa !important;
}
</style>
<div class="modal fade" id="confirmparentPopup" role="dialog" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">×</button>
          <h4 class="modal-title">Confirm PIN</h4>
        </div>
        <div class="modal-body">
          <input type="password" id="parentPass" class="form-control commoncs2" placeholder="Enter PIN" value="">
          <a href="#parentPass" data-currenteye="show" data-faid="fappass" class="showbtn popsbtn"><i class="fa fa-eye-slash" id="fappass" aria-hidden="true"></i></a>
        </div>
        <div class="modal-footer">
          <button type="button" id="confirmpasswordbtn" class="btn btn-primary">Confirm <i class="fa fa-spin fa-spinner hideOnLoad" id="checkingprocess3"></i></button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
 <nav class="navbar navbar-inverse navbar-static-top">
    <div class="container full-container navb-fixid">
      <div class="navbar-header">
        <div id="showLeft" class="cat-toggle hide"> <span></span> <span></span> <span></span> <span></span> </div>
        <button type="button" class="navbar-toggle collapsed pull-right" data-toggle="offcanvas"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
      </div>
      <a class="brand" href="dashboard.php"><img class="img-responsive" src="images/logo.png" alt="" onerror="this.src='img/logo.png';"></a>
      <div id="navbar" class="collapse navbar-collapse sidebar-offcanvas">
                <ul class="nav navbar-nav navbar-left main-icon">
          <li class=""><a href="index.php"><span class="da home"></span><span>Home</span></a></li>
          <li class=""><a href="live.php"><span class="da live"></span><span>Live Tv</span></a></li>
          <li class=""><a href="movies.php"><span class="da movie"></span><span>Movies</span></a></li>
          <li class=""><a href="series.php"><span class="da tv"></span><span>Tv series</span></a></li>
          <li class=""><a href="radio.php"><span class="da radio"></span><span>Radio</span></a></li>
          <li class=""><a href="catchup.php"><span class="da catchup"></span><span>Catch Up</span></a></li>
          <!-- <li class=""><a href="radio.php"><span class="da radio"></span><span>Radio</span></a></li> -->
          
        </ul>
        <ul class="nav navbar-nav navbar-right r-icon">
                      <li class="r-li"><a href="#" "="" class="logoutBtn"><i class="fa fa-sign-out"></i><span class="r-show">Logout</span></a></li>
                  </ul>
            </div>
      <!--/.nav-collapse --> 
    </div>
  </nav>




  
  <div class="modal fade" id="ConfirmParentPassword" role="dialog" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">×</button>
          <h4 class="modal-title">Update PIN</h4>
        </div>
        <div class="modal-body">
              <input type="password" id="poldpassword" class="form-control commoncs2" placeholder="Old PIN" value="">
              <a href="#poldpassword" data-currenteye="show" data-faid="faoldpass" class="showbtn popsbtn"><i class="fa fa-eye-slash" id="faoldpass" aria-hidden="true"></i></a>
              <br>
              <input type="password" id="pmainpassword" class="form-control commoncs2" placeholder="New PIN" value="">
              <a href="#pmainpassword" data-currenteye="show" data-faid="fanewpass" class="showbtn popsbtn"><i class="fa fa-eye-slash" id="fanewpass" aria-hidden="true"></i></a>
              <br>
              <input type="password" id="pconnpassword" class="form-control commoncs2" placeholder="Confirm PIN" value="">
              <a href="#pconnpassword" data-currenteye="show" data-faid="faconpass" class="showbtn popsbtn"><i class="fa fa-eye-slash" id="faconpass" aria-hidden="true"></i></a>
        </div>
        <div class="modal-footer">
          <button type="button" id="updateparentpasswordbtn" class="btn btn-primary">Update <i class="fa fa-spin fa-spinner hideOnLoad" id="checkingprocess2"></i></button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

  <div class="container-fluid">
  <center id="fullLoader" class="hideOnLoad"><img src="images/roundloader.gif"><p class="text-center">LOADING DATA</p></center>
  
  <div class="col-md-12 container-holder">
    <div class="container col-md-8 col-md-offset-2">
        <h2 class="text-center heading main-sheading">SETTINGS</h2>
        <div class="col-md-12 commonsectionclass">
          <table class="table table-bordered">
            <tbody><tr>
              <td colspan="2">
                  <h3 class="SettingsHeadings">Player Settings</h3>
              </td>
            </tr>
            <tr class="hideOnLoad">
              <td class="common-td">
                Live Player
              </td>
              <td>
                <select id="live_player" class="form-control">
                  <option value="JW Player">JW Player</option>
                  <!-- <option  value="Flow player">Flow player</option> -->
                </select>
              </td>
            </tr>
            <tr>
              <td class="common-td">
                Select default player for movies section
              </td>
              <td>
                <select id="movie_player" class="form-control">
                  <option value="JW Player">JW Player</option>
                  <option value="Flow player">Flow player</option>
                  <option value="AJ player">AJ player</option>
                </select>
              </td>
            </tr>
            <tr>
              <td class="common-td"> 
                Select default player for Series section
              </td>
              <td>
                <select id="series_player" class="form-control">
                  <option value="JW Player">JW Player</option>                  
                  <option value="Flow player">Flow player</option>
                  <option value="AJ player">AJ player</option>
                </select>
              </td>
            </tr>
         </tbody></table>  
        </div>
        <div class="col-md-12 commonsectionclass"> 
         <table class="table table-bordered"> 
            <tbody><tr>
              <td colspan="2">
                  <h3 class="SettingsHeadings">Time Settings</h3>
              </td>
            </tr>
            <tr>
              <td class="common-td">
                Time Format
              </td>
              <td>
                <select id="timeformat" class="form-control">
                    <option value="12" selected="selected">12 Hours Format</option>
                    <option value="24">24 Hours Format</option>
                </select>
              </td>
            </tr>
            <tr>
              <td class="common-td">
                Epg Time Shift
              </td>
              <td>
                <select id="epgtimeshift" class="form-control">
                                        <option value="-12">-12</option>
                                          <option value="-11">-11</option>
                                          <option value="-10">-10</option>
                                          <option value="-9">-9</option>
                                          <option value="-8">-8</option>
                                          <option value="-7">-7</option>
                                          <option value="-6">-6</option>
                                          <option value="-5">-5</option>
                                          <option value="-4">-4</option>
                                          <option value="-3">-3</option>
                                          <option value="-2">-2</option>
                                          <option value="-1">-1</option>
                                      <option value="0" selected="selected">0</option>
                                        <option value="+1">+1</option>
                                          <option value="+2">+2</option>
                                          <option value="+3">+3</option>
                                          <option value="+4">+4</option>
                                          <option value="+5">+5</option>
                                          <option value="+6">+6</option>
                                          <option value="+7">+7</option>
                                          <option value="+8">+8</option>
                                          <option value="+9">+9</option>
                                          <option value="+10">+10</option>
                                          <option value="+11">+11</option>
                                          <option value="+12">+12</option>
                                    </select>
              </td>
            </tr>
          </tbody></table>
        </div>
        <div class="col-md-12 commonsectionclass">  
         <table class="table table-bordered"> 
            <tbody><tr>
              <td colspan="2">
                  <h3 class="SettingsHeadings" id="parentheading">Parental Control Setting</h3>
              </td>
            </tr>            
            <tr>
              <td class="common-td">
                <div class="row">
                  <div class="col-md-12" style="margin-top: 16px; text-align: center;">
                    <span id="showentext" style="position: relative; top: -15px;">Enable</span>
                    <label class="switch ">
                      <input type="checkbox" id="enablecheckebox" data-afterenable="">
                      <span class="slider round"></span>
                    </label>
                  </div>
                </div>
              </td>
              <td style="height: 140px;">
                                          <input type="password" id="parentmainpassword" class="form-control commoncs disableInputs" placeholder="New PIN" value="" readonly="readonly">
                        <a href="#parentmainpassword" data-currenteye="show" data-faid="fanewpassword" class="showbtn"><i class="fa fa-eye-slash" id="fanewpassword" aria-hidden="true"></i></a>
                        <br>
                        <input type="password" id="parentconpassword" class="form-control commoncs disableInputs" placeholder="Confirm PIN" value="" readonly="readonly">
                        <a href="#parentconpassword" data-currenteye="show" data-faid="fanconewpassword" class="showbtn"><i class="fa fa-eye-slash" id="fanconewpassword" aria-hidden="true"></i></a>
                                  </td>
            </tr>
            
          </tbody></table>
        </div>
          <div class="col-md-12">
          <p style="text-align: right;color: #717171;margin: 0;">V 1.7</p>
          </div>
          <div class="col-md-12" style="margin-bottom: 10px;">
            <center>

             <div class="alert alert-success " id="SuccessMessage">
                <strong>Success!</strong> Changes Saved Successfully.
             </div>
            <button class="btn btn-primary rippler rippler-default" id="SaveSettings">Save Changes <i class="fa fa-spin fa-spinner hideOnLoad" id="checkingprocess"></i></button></center>
          </div>
        </div>
    </div>
  </div>
</div>
<script type="text/javascript">
   $(document).ready(function(){
      $(".commoncs").click(function(){
          if ( $(this).is('[readonly]') ) { 
            swal({
                  title: 'Error!',
                  text: 'Please Enable First!!!',
                  icon: 'warning'
                 });
          }
      });

      $(".showbtn").click(function(e){
          e.preventDefault();
          var currenteye = $(this).data('currenteye');
          var InputID = $(this).attr('href')
          var faid = $(this).data('faid');
          if(currenteye == "hide")
          {
          	$(this).data('currenteye','show');
          	$(InputID).attr('type','password');
          	$("#"+faid).removeClass("fa fa-eye");
          	$("#"+faid).addClass("fa fa-eye-slash");
          }
          else
          {
          	$(this).data('currenteye','hide')
          	$(InputID).attr('type','text');
          	$("#"+faid).removeClass("fa fa-eye-slash");
          	$("#"+faid).addClass("fa fa-eye");
          }
      });

      checkboxfunction();
      $('#UpdateParentPassword').click(function(){
          $('#ConfirmParentPassword').modal('show');
      });
      $('#enablecheckebox').click(function(e){
          if($(this).data('afterenable') == 1)
          {
            e.preventDefault();
/*            $("#parentPass").addClass("addredborder");*/
            $("#parentPass input[type=password]").focus();
            $('#confirmparentPopup').modal('show');

          }
          else
          {
            checkboxfunction();
          }
      });

      $('#confirmpasswordbtn').click(function(){   
          var  parentenable = "on";
          var  parentenableMessage = "Enabled";
          if($('#enablecheckebox').prop('checked') == true)
          {
             parentenable = "";   
             parentenableMessage = "Disabled";  
          } 
          $("#parentPass").removeClass('addredborder');    
          var parentPass = $("#parentPass").val();
          if(parentPass == "")
          {
            $("#parentPass").addClass('addredborder');
          }
          else
          {
            $('#checkingprocess3').removeClass('hideOnLoad');
            jQuery.ajax({
            type:"POST",
            url:"includes/ajax-control.php",
            dataType:"text",
            data:{
              action:'confirm_parentpassword',
              parentPass:parentPass
            },  
              success:function(response2){ 
                $('#checkingprocess3').addClass('hideOnLoad');
                 if(response2 != 0)
                 {
                    var savedparentpassword = "";
                    var live_player = $("#live_player");
                    var movie_player = $("#movie_player");
                    var series_player = $("#series_player");
                    var epgtimeshift_selector = $("#epgtimeshift");
                    var timeformat_selector = $("#timeformat");

                    var live_player_val = live_player.val();
                    var movie_player_val = movie_player.val();
                    var series_player_val = series_player.val();
                    var epgtimeshift_val = epgtimeshift_selector.val();
                    var timeformat_val = timeformat_selector.val();
                    jQuery.ajax({
                      type:"POST",
                      url:"includes/ajax-control.php",
                      dataType:"text",
                      data:{
                      action:'SaveSettings',
                      live_player_val:live_player_val,
                      movie_player_val:movie_player_val,
                      series_player_val:series_player_val,
                      epgtimeshift_val:epgtimeshift_val,
                      parentenable:parentenable,
                      parentmainpassword_val:savedparentpassword,
                      timeformat_val:timeformat_val
                      },  
                        success:function(response2){
                           $('#checkingprocess2').addClass('hideOnLoad');
                           swal({
                            text: 'PIN Successfully '+parentenableMessage,
                            button:false,
                            icon: 'success'
                           });
                           setTimeout (function(){
                            swal.close();
                            location.reload();
                           },2000)
                           /*$('#SuccessMessage').animate({'top':'67px'}, 300 );
                           setTimeout (function(){
                            $('#SuccessMessage').animate({'top':'-100%'}, 300 );
                           },2000)*/
                        }
                    });
                    /*$('#parentPass').val('');
                    $('#confirmparentPopup').modal('hide'); 
                    if($('#enablecheckebox').prop('checked') == true)
                    {
                      $('#showentext').text('Enable');
                      $('#enablecheckebox').prop('checked', false);  
                      $('#UpdateParentPassword').attr("disabled", true);
                    }
                    else
                    {
                      $('#showentext').text('Disable');
                      $('#enablecheckebox').prop('checked', true);
                      $('#UpdateParentPassword').attr("disabled", false);
                    } */
                 }
                 else
                 {
                    swal({
                        title: 'Error!',
                        text: 'Invalid PIN !!!',
                        icon: 'warning'
                       });
                 }             
              }
            });
          }
      });

      //Update Parent Password Section..
      $('#updateparentpasswordbtn').click(function(){
          var updatevalidationcondition = 1;
          var savedparentpassword = "";
          $(".commoncs2").removeClass("addredborder");
          var live_player = $("#live_player");
          var movie_player = $("#movie_player");
          var series_player = $("#series_player");
          var epgtimeshift_selector = $("#epgtimeshift");
          var timeformat_selector = $("#timeformat");

          var poldpassword = $("#poldpassword");
          var pmainpassword = $("#pmainpassword");
          var pconnpassword = $("#pconnpassword");

          var live_player_val = live_player.val();
          var movie_player_val = movie_player.val();
          var series_player_val = series_player.val();
          var epgtimeshift_val = epgtimeshift_selector.val();
          var timeformat_val = timeformat_selector.val();

          var poldpassword_val = poldpassword.val();
          var pmainpassword_val = pmainpassword.val();
          var pconnpassword_val = pconnpassword.val();

          if(poldpassword_val == "")
          {
            updatevalidationcondition = 0;
            $("#poldpassword").addClass('addredborder');
          }
          if(pmainpassword_val == "")
          {
            updatevalidationcondition = 0;
            $("#pmainpassword").addClass('addredborder');
          }
          if(pconnpassword_val == "")
          {
            updatevalidationcondition = 0;
            $("#pconnpassword").addClass('addredborder');
          }

          if(updatevalidationcondition == 1)
          {
              if(poldpassword_val != savedparentpassword)
              {
                swal({
                  title: 'Error!',
                  text: 'Old PIN is incorrect !!!',
                  icon: 'warning'
                 });
                 updatevalidationcondition = 0;
              }
          }

          if(updatevalidationcondition == 1)
          {
              if(pmainpassword_val != pconnpassword_val)
                  {
                    swal({
                      title: 'Error!',
                      text: 'New PIN does not matach with confirm PIN !!!',
                      icon: 'warning'
                     });
                    updatevalidationcondition = 0;
                  }
          }
          
          if(updatevalidationcondition == 1)
          {
            $('#checkingprocess2').removeClass('hideOnLoad');
            jQuery.ajax({
              type:"POST",
              url:"includes/ajax-control.php",
              dataType:"text",
              data:{
              action:'SaveSettings',
              live_player_val:live_player_val,
              movie_player_val:movie_player_val,
              series_player_val:series_player_val,
              epgtimeshift_val:epgtimeshift_val,
              parentenable:"on",
              parentmainpassword_val:pmainpassword_val,
              timeformat_val:timeformat_val
              },  
                success:function(response2){
                   $('#checkingprocess2').addClass('hideOnLoad');
                   swal({
                    text: 'PIN Successfully Upadeted',
                    button:false,
                    icon: 'success'
                   });
                   setTimeout (function(){
                    swal.close();
                    location.reload();
                   },2000)
                   /*$('#SuccessMessage').animate({'top':'67px'}, 300 );
                   setTimeout (function(){
                    $('#SuccessMessage').animate({'top':'-100%'}, 300 );
                   },2000)*/
                }
              });
          }


      });
      $(document).on("click", "#SaveSettings", function(){
        SaveSettingsFunction();
      });
    });

   function checkboxfunction()
   {
      $(".commoncs").removeClass("addredborder");
      if($('#enablecheckebox').prop('checked') == true)
          {
            $('.showbtn').removeClass('hideOnLoad');
            $('#showentext').text('Disable');
            $('.commoncs').removeClass('disableInputs');
            $('.commoncs').attr("readonly", false);
            $('#UpdateParentPassword').attr("disabled", false);
          }
          else
          {
            $('.showbtn').removeClass('hideOnLoad');
            $('#showentext').text('Enable');
            $('.commoncs').addClass('disableInputs');
            $('.commoncs').attr("readonly", true);
            $('#UpdateParentPassword').attr("disabled", true);
          }
   }

function SaveSettingsFunction()
{
  $(".commoncs").removeClass("addredborder");
  var parentenable = "";
  var validationcondition = 1;
  var parentmainpassword_val = "";
   
  if($('#enablecheckebox').prop('checked') == true)
  {
      parentenable = "on";
      if($("#UpdateParentPassword").length == 0)
      {
        parentmainpassword_val = $("#parentmainpassword").val();
        parentconpassword_val = $("#parentconpassword").val();
        if(parentmainpassword_val == "")
        {
          validationcondition = 0;
          $("#parentmainpassword").addClass('addredborder');
        }

        if(parentconpassword_val == "")
        {
          validationcondition = 0;
          $("#parentconpassword").addClass('addredborder');
        }
        if(parentmainpassword_val != parentconpassword_val)
        {
          swal({
            title: 'Error!',
            text: 'New PIN does not matach with confirm PIN !!!',
            icon: 'warning'
           });
          validationcondition = 0;
        } 
      }
  }

  if(validationcondition == 1)
  {
    
    $('#checkingprocess').removeClass('hideOnLoad');
    var live_player = $("#live_player");
    var movie_player = $("#movie_player");
    var series_player = $("#series_player");
    var epgtimeshift_selector = $("#epgtimeshift");
    var timeformat_selector = $("#timeformat");

    var live_player_val = live_player.val();
    var movie_player_val = movie_player.val();
    var series_player_val = series_player.val();
    var epgtimeshift_val = epgtimeshift_selector.val();
    var timeformat_val = timeformat_selector.val();

    jQuery.ajax({
      type:"POST",
      url:"includes/ajax-control.php",
      dataType:"text",
      data:{
      action:'SaveSettings',
      live_player_val:live_player_val,
      movie_player_val:movie_player_val,
      series_player_val:series_player_val,
      epgtimeshift_val:epgtimeshift_val,
      parentenable:parentenable,
      parentmainpassword_val:parentmainpassword_val,
      timeformat_val:timeformat_val
      },  
        success:function(response2){
           $('#checkingprocess').addClass('hideOnLoad');
           swal({
            text: 'Settings saved',
            button:false,
            icon: 'success'
           });
           setTimeout (function(){
            swal.close();
            location.reload();
           },2000)
           /*$('#SuccessMessage').animate({'top':'67px'}, 300 );
           setTimeout (function(){
            $('#SuccessMessage').animate({'top':'-100%'}, 300 );
           },2000)*/
        }
      });  
  }
}   
</script>
    
<div class="pattern-over"></div>
<!--- Body pattern--->
  <img class="body-bg" src="images/bg.jpg" alt=""><!--- Body Background---> 
<!-- Movie MODAL CODE -->
<div class="modal fade movie-popup" id="movieModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    
    <!-- /.modal-content -->
    </div>
  <!-- modal-dialog --> 
 <!--  <img class="body-bg" src="images/mainBlurBG.jpg" alt=""> --><!--- Body Background--> 
</div>

<div class="modal fade movie-popup" id="accountModal1" tabindex="-1" role="dialog" aria-labelledby="AccountModal" aria-hidden="true" style="z-index: 999;">
  <div class="modal-dialog">
   <div class="modal-content">
          <div class="modal-header" style="border:0;"> <span class="p-close" data-dismiss="modal" aria-hidden="true">x</span> </div>
          <div class="modal-body">
            <div class="popup-content t-s">
              

                   <div class="info_set clearfix" style="width:50%; position: relative; left: 25%; margin-top: 5%; color: #000; background: #fff">
<h1 class="text-center" style="color: #000;">Account Information</h1>
                      <div class="col-lg-4 col-md-4 col-sm-4 col-xs-6">

                         <span>Username</span>

                         <p style="width: 100%; overflow: hidden; text-overflow: ellipsis;" title="admin">admin</p>

                      </div>

                      <div class="col-lg-4 col-md-4 col-sm-4 col-xs-6">

                         <span>Status</span>

                         <p>Active</p>

                      </div>

                      <div class="col-lg-4 col-md-4 col-sm-4 col-xs-6">

                         <span>Expiry date</span>

                         <p>
                             Unlimited                         </p>

                      </div>

                      <div class="col-lg-4 col-md-4 col-sm-4 col-xs-6">

                         <span>Is trial</span>

                         <p>

                             No                         </p>

                      </div>

                      <div class="col-lg-4 col-md-4 col-sm-4 col-xs-6">

                         <span>Active Connections</span>

                         <p>0</p>

                      </div>

                      <div class="col-lg-4 col-md-4 col-sm-4 col-xs-6">

                         <span>Created at</span>

                         <p>
                          May 24, 2020                         </p>

                      </div>

                      <div class="col-lg-4 col-md-4 col-sm-4 col-xs-6">

                         <span>Max connections</span>

                         <p>1</p>

                      </div>

                   </div>                       
              </div>
            </div>
          </div>
    <!-- /.modal-content -->
    </div>
  <!-- modal-dialog --> 
 <!--  <img class="body-bg" src="images/mainBlurBG.jpg" alt=""> --><!--- Body Background---> 
</div>
<!--Movie-popup End--> 

<!--Saerch-popup Start-->
<div id="search">
    <button type="button" class="close">×</button>
        <input type="search" value="" id="SearchData" placeholder="type keyword(s) here">
        <button type="submit" id="SearchBtn" class="btn btn-primary">Search</button>
</div>
<!--Saerch-popup End-->
<!-- jQuery (JavaScript plugins) --> 


<script src="js/offcanvas.js"></script> 
<script src="js/bootstrap.js"></script> 
<script src="js/classie.js"></script> 
<script src="js/owl.carousel.min.js"></script> 
<!-- <script src="js/scrollbar.js"></script> --> 
<script src="js/plugin.js"></script>
<script src="js/jquery.infinitescroll.min.js"></script> 
<script src="js/freewall.js"></script> 
<script type="text/javascript" src="js/Manualcustom.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<!-- <script src='https://content.jwplatform.com/libraries/fgbTqCCh.js'></script> -->
<!-- <script src="//cdnjs.cloudflare.com/ajax/libs/less.js/3.7.1/less.min.js" ></script> -->
<script src="js/jquery.rippler.min.js"></script>




<script>
/*-------- Load more Start  ----------*/
$(document).ready(function() {

$(document).find(".rippler, li").rippler({
    effectClass      :  'rippler-effect'
    ,effectSize      :  0      // Default size (width & height)
    ,addElement      :  'div'   // e.g. 'svg'(feature)
    ,duration        :  400
  });

  $('#accountModal').click(function(){
    $('#accountModal1').modal('show');
  })

$('#cbp-spmenu-s1 li a').click(function(){
  $('#cbp-spmenu-s1 li a').removeClass('active');
  $(this).addClass('active');

    classie.toggle( showLeft, 'active' );
    classie.toggle( menuLeft, 'cbp-spmenu-open' );
    $('.cat-toggle').toggleClass('open');
})

$(document).on('click','.showCast',function(){
  
  $(this).parent('.i-cast').toggleClass('openCast');
  
  if($(this).text() == 'Show Cast')
  {
    $(this).text('Hide Cast');
  }
  else
  {
    $(this).text('Show Cast');
  }
  

})
$('#menuModal').on('hidden.bs.modal', function () {
  clearInt();
   $('#player-holder').html('');
   $('.backToInfo').addClass('hideOnLoad');
   $(document).find('.PlayerHolder div').html('').addClass('hideOnLoad');
   clearInt();
})

$(document).on('click','.backToInfo',function(){
  if($('#player-holder').hasClass('flowplayer'))
  {
   var container = document.getElementById("player-holder");
    flowplayer(container).shutdown(); 
  }
  
  $('#player-holder').html('');

  $('#player-holder, .backToInfo').addClass('hideOnLoad');

    var episID = $(this).data('episid');
    if(episID)
    {
      $('#epis-'+episID+'').removeClass('hideOnLoad');
    }
    else
    {
      $('.poster-details').removeClass('hideOnLoad');
    }
    clearInt();
  })

  
  setInterval(function(){
  var date = new Date();
  var hours = date.getHours();
  var minutes = date.getMinutes();
  var ampm = hours >= 12 ? 'PM' : 'AM';
  hours = hours % 12;
  hours = hours ? hours : 12; // the hour '0' should be '12'
  minutes = minutes < 10 ? '0'+minutes : minutes;
  var strTime = hours + ':' + minutes + ' ' + ampm;
  $('.time').html(strTime);
  },1000)
  /*setInterval(function(){
  var hr = date.getHours();
  var mins = date.getMinutes();
    $('.time').html(hr+':'+mins)
  },1000)*/
var win = $(window);

// Each time the user scrolls
/*win.scroll(function() {
  // End of the document reached?
  if ($(document).height() - win.height() == win.scrollTop()) {
    $('#loading').show();

    $.ajax({
      url: 'get-post.php',
      dataType: 'html',
      success: function(html) {
        $('#posts ul').append(html);
        $('#loading').hide();
      }
    });
  }
});*/
});
/*-------- Load more End ----------*/
/*-------- Grids Start ----------*/
$(function() {
        $(".free-wall").each(function() {
          var wall = new Freewall(this);
          wall.reset({
            selector: '.thumb-b',
            animate: true,
            cellW: 185,
            cellH: 278,
            fixSize: 0,
            gutterY: 0,
            gutterX: -15,
            onResize: function() {
              wall.fitWidth();
            }
          })
          wall.fitWidth();
        });
        $(window).trigger("resize");
      });
/*-------- Grids End ----------*/