<?php 
$XCStreamHostUrl = "http://suadns";
$XClogoLinkval = "/images/favicon.ico";
$XCcopyrighttextval = "";
$XCcontactUslinkval = "";
$XChelpLinkval = "";
$XClicenseIsval = "smarters";
$XClocalKey = "";
$XCsitetitleval = "";
?>