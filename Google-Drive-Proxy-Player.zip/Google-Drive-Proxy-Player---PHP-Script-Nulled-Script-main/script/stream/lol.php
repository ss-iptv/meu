<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <style media="screen">
    *{
      padding: 0;
      margin:0;
      box-sizing: bor

    }
      body{
background: #010101;
display: flex;
justify-content: center;

align-items: center;
height: 100vh;
      }
    </style>
  </head>
  <body>
<img src='https://c-sf.smule.com/rs-s24/arr/6a/2b/93656b62-2a01-4649-b2f3-84e9d0dde40a.jpg' alt='error'>
  </body>
</html>
